from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from plot_print import _save

root = Path(__file__).resolve().parent
rows = [line.strip("|").split("|") for line in (root / "results.md").read_text(encoding="utf-8-sig").splitlines() if line.startswith("|")]
values = [[float(v.strip().replace(",", ".")) for v in row[1:]] for row in rows[2:9]]
def chart(name, labels, series, xlabel, target=False):
    fig, ax = plt.subplots(figsize=(8, max(3, len(labels)*.37+1.5)))
    y = np.arange(len(labels))
    for j,(legend, data) in enumerate(series):
        offset=(j-(len(series)-1)/2)*.35
        bars=ax.barh(y+offset,data,height=.30 if len(series)>1 else .56,color=["#444444","#bbbbbb"][j],edgecolor="black",label=legend)
        ax.bar_label(bars, labels=[f"{v:.2f}".replace(".",",") for v in data],padding=4,fontsize=8)
    ax.set_yticks(y,labels)
    ax.invert_yaxis()
    ax.set_xlabel(xlabel)
    ax.set_xlim(0,113)
    ax.set_xticks(range(0,101,20))
    if target:
        ax.axvline(90,color="black",linestyle=":",linewidth=1,label="Цель 90%")
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.24 if len(labels)<6 else -.06),ncol=3,frameon=False)
    _save(fig,root,name)

chart("01_recall",["Все интервалы","Основные сценарии¹","Слабые сценарии¹"],[("Исходный TICD",values[0][:3]),("Доработанный TICD",values[3][:3])],"Полнота, %     ¹ Среднее по сценариям",True)
chart("02_telemetry",["Штатный отчёт","Нормировка долей","Округление до 0,01","Согласованный отчёт"],[("Доработанный TICD",[values[i][0] for i in [3,4,6,5]])],"Общая полнота, %",True)
cases=sorted([(float(row[3].strip().replace(",",".")),row[0].strip()) for row in rows[11:] if int(row[1])>0])
chart("03_scenarios",[k for v,k in cases],[("Доработанный TICD",[v for v,k in cases])],"Полнота по сценарию, %",True)

